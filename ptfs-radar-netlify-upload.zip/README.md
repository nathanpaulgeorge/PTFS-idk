# PTFS Radar Netlify upload

This folder is already the Netlify site root. `index.html` and `assets/` must stay at this level.

## Netlify upload

For the visual site, upload the contents of this folder to Netlify, or upload the provided ZIP without adding another parent folder.

For the live Roblox server and username endpoints, deploy this folder as a Netlify site through the Netlify CLI or a connected repository so Netlify also installs the functions in `netlify/functions`.

## Real-data limitation

The site does not invent aircraft, pilots, airlines, airports, photos, or takeoff/landing events. Roblox's public API exposes PTFS public server data and username resolution, but not in-game aircraft telemetry. Configure a permitted PTFS bridge in the app to display those additional real fields.