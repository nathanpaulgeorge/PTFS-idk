export async function handler(event) {
  const method = event?.httpMethod ?? event?.requestContext?.http?.method;
  if (method !== "POST") {
    return json({ error: "Method not allowed." }, 405);
  }

  let body;
  try {
    const rawBody = event?.isBase64Encoded
      ? Buffer.from(event.body || "", "base64").toString("utf8")
      : event?.body;
    body = typeof rawBody === "string" ? JSON.parse(rawBody || "{}") : rawBody || {};
  } catch {
    return json({ error: "Invalid request body." }, 400);
  }

  const username = typeof body.username === "string" ? body.username.trim() : "";
  if (!username || username.length > 20) {
    return json({ error: "Enter a Roblox username up to 20 characters." }, 400);
  }

  try {
    const response = await fetch("https://users.roblox.com/v1/usernames/users", {
      method: "POST",
      headers: {
        accept: "application/json",
        "content-type": "application/json",
      },
      body: JSON.stringify({
        usernames: [username],
        excludeBannedUsers: false,
      }),
    });

    if (!response.ok) {
      return json({ error: "Roblox user lookup is unavailable right now." }, 502);
    }

    const payload = await response.json();
    const user = payload.data?.[0] ?? null;
    return json({
      user,
      membership: "not-exposed-by-roblox-public-api",
      message: user
        ? "The username is real, but Roblox does not expose which PTFS server currently contains that player."
        : "No Roblox user matched that username.",
    });
  } catch {
    return json({ error: "Roblox user lookup is unavailable right now." }, 502);
  }
}

function json(body, statusCode = 200) {
  return {
    statusCode,
    headers: {
      "content-type": "application/json",
      "cache-control": "no-store",
    },
    body: JSON.stringify(body),
  };
}