const PLACE_ID = 20321167;

export async function handler() {
  try {
    const response = await fetch(
      `https://games.roblox.com/v1/games/${PLACE_ID}/servers/Public?sortOrder=2&excludeFullGames=false&limit=100`,
      { headers: { accept: "application/json" } },
    );

    if (!response.ok) {
      return json({ error: "Roblox server list is unavailable right now." }, 502);
    }

    const payload = await response.json();
    return json({
      placeId: PLACE_ID,
      source: "Roblox public servers API",
      fetchedAt: new Date().toISOString(),
      nextPageCursor: payload.nextPageCursor ?? null,
      servers: (payload.data ?? []).map((server) => ({
        ...server,
        joinUrl: `https://www.roblox.com/games/start?placeId=${PLACE_ID}&gameInstanceId=${encodeURIComponent(server.id)}`,
      })),
    });
  } catch {
    return json({ error: "Roblox server list is unavailable right now." }, 502);
  }
}

function json(body, statusCode = 200) {
  return {
    statusCode,
    headers: {
      "content-type": "application/json",
      "cache-control": "no-store",
    },
    body: JSON.stringify(body),
  };
}